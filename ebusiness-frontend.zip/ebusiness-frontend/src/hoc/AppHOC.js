import React, { Component } from 'react';

import Header from '../containers/Header';

const appHOC = WrappedComponent =>
  class extends Component {
    render() {
      return (
        <div style={{ minHeight: '100vh' }} className="has-background-light">
          <Header />
          <center>
          <h2>Sample texts</h2>
          <img src="https://www.iconsdb.com/icons/preview/green/plus-5-xxl.png" alt="Plus" width="200" height="111"></img>
          <form id="form"> 
          <input type="search" id="query" name="q" placeholder="Search..."></input>
          <button>Search</button>
          </form>
          </center>
          <div
            style={{ marginTop: '20px' }}
            className="container is-fluid mt-2"
          >
            <WrappedComponent {...this.props} />
          </div>
        </div>
      );
    }
  };

export default appHOC;
