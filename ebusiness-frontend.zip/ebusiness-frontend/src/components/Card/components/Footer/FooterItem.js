import React from 'react';

const cardFooterItem = props => (
  <div className="card-footer-item">{props.children}</div>
);

export default cardFooterItem;
