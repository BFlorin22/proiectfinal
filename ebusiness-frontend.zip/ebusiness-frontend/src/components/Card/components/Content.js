import React from 'react';

const cardContent = props => (
  <div className="card-content">{props.children}</div>
);

export default cardContent;
