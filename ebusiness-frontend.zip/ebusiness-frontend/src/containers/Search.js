import React, { Component } from 'react';

import { connect } from 'react-redux';
import { categoryActions, productActions } from '../store/actions';

import Select from '../components/Select';
import Card from '../components/Card';
import Button from '../components/Button';

class Search extends Component {
  componentDidMount() {}

  render() {
    return (
      <div style={{ minHeight: '100vh' }} className="has-background-light">
          <center>
          <h2>Sample texts</h2>
          <img src="https://www.iconsdb.com/icons/preview/green/plus-5-xxl.png" alt="Plus" width="200" height="111"></img>
          <form id="form"> 
          <input type="search" id="query" name="q" placeholder="Search..."></input>
          <button>Search</button>
          </form>
          </center>
          <div
            style={{ marginTop: '20px' }}
            className="container is-fluid mt-2"
          >
            
          </div>
        </div>
    );
  }
}

const mapStateToProps = state => ({
  categories: state.category.categories,
  categorySearch: state.product.categorySearch,
  sortFilter: state.product.sortFilter
});

const mapDispatchToProps = dispatch => ({
  getCategories: () => dispatch(categoryActions.getCategories()),
  setCategorySearch: value => dispatch(productActions.setCategorySearch(value)),
  setSortSearch: value => dispatch(productActions.setSortSerach(value))
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Search);
