module.exports = {
  plugins: ['babel-plugin-jsx-remove-data-test-id']
};
