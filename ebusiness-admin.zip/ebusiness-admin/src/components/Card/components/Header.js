import React from 'react';

const cardHeader = props => <div className="card-header">{props.children}</div>;

export default cardHeader;
