import React from 'react';

const cardImage = props => <div className="card-image">{props.children}</div>;

export default cardImage;
