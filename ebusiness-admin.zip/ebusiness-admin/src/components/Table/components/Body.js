import React from 'react';

const body = props => <tbody>{props.children}</tbody>;

export default body;
