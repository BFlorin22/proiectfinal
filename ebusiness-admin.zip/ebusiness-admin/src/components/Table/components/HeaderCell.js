import React from 'react';

const headerCell = props => <th>{props.children}</th>;

export default headerCell;
