import React from 'react';

const footer = props => <tfoot>{props.children}</tfoot>;

export default footer;
