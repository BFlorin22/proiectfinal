import React from 'react';

const row = props => <tr>{props.children}</tr>;

export default row;
