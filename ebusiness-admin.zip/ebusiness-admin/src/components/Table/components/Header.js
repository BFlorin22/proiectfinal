import React from 'react';

const header = props => <thead>{props.children}</thead>;

export default header;
