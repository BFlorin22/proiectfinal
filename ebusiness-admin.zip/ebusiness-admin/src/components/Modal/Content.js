import React from 'react';

const content = props => (
  <div className="modal-card-body">{props.children}</div>
);

export default content;
