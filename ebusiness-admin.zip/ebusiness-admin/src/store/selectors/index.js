import error from './error';
import loading from './loading';

export const createErrorSelector = error;
export const createLoadingSelector = loading;
