import { productTypes } from '../actionTypes';

import actionsCreator from '../../lib/actionsCreator';

export default actionsCreator(productTypes);
